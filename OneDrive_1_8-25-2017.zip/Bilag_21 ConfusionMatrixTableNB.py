# -*- coding: utf-8 -*-
"""
Created on Fri Aug 25 11:06:48 2017

@author: Julius Markedal
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Aug 24 17:06:03 2017

@author: Julius Markedal
"""

############################################################################
############ Confusion Matrix DataFrame ####################################
############################################################################
import pandas as pd
import re
import nltk
import sklearn
from sklearn import metrics
from sklearn.cross_validation import train_test_split as tts
from sklearn.linear_model import LogisticRegression
#%%
df_matrix = pd.DataFrame([])
#%%
df= pd.read_csv('C:/Users/Julius Markedal/desktop/python/sds/TestAndTrainMatrix_inclOtherIgnore.csv')
df = df.drop('Unnamed: 0', axis = 1)
df.iloc[3888, df.columns.get_loc('int_pol')] = 1
df.iloc[3518, df.columns.get_loc('int_pol')] = 1
#%%
stemmer = nltk.stem.snowball.DanishStemmer()
def prep(text):
    wordlist = nltk.word_tokenize(text)
    wordlist = [stemmer.stem (w) for w in wordlist]
    pattern = '^[,;:?Â«<>Â»]+$'
    text = re.sub(pattern,'', text)
    
    return wordlist

def custom_tokenize(text):
   
    text = re.sub('^[,;:?Â«<>Â»]+$','',text)
    
    wordlist = prep(text) # our old function
    wordlist = [word.strip('.,"?') for word in wordlist]
    return wordlist
#%%
Emne = ['int_pol', 'fam_id', 'ignorer', 'kon_kon', 'kul_rel', 'mil_kli', 'other', 'sta_tek']
true_positive = []
false_positive = []
true_negative = []
false_negative = []
f1 = []
accuracy = []
recall = []
precision = []

#%%
# Int_pol
vectorizer = sklearn.feature_extraction.text.CountVectorizer(tokenizer=custom_tokenize) # Tfidf
X  =   vectorizer.fit_transform(df['par_txt'])
y,y_index = pd.factorize(df['int_pol'])

X_train, X_test, y_train, y_test = tts(X, y, random_state=1)

nb = MultinomialNB(alpha=0.16410204081632654, class_prior=None, fit_prior=True)

# train the model using X_train_dtm
nb.fit(X_train, y_train)

# make class predictions for X_test_dtm
y_pred_class = nb.predict(X_test)

# calculate predicted probabilities for X_test_dtm (well calibrated)
#y_pred_prob = logreg.predict_proba(X_test_dtm)[:, 1]

print(metrics.confusion_matrix(y_test, y_pred_class))
print('acc: ',metrics.accuracy_score(y_test, y_pred_class))
print('recall: ',metrics.recall_score(y_test, y_pred_class))
print('prec: ',metrics.precision_score(y_test, y_pred_class))
print('f1: ',metrics.f1_score(y_test, y_pred_class))
#%%
bool1 = y_pred_class == 1
bool2 = y_test == 1
bool3 = y_pred_class == 0
bool4 = y_test == 0

#%%
true_positive.append(sum(bool1 & bool2))
false_positive.append(sum(bool1 & bool4))
true_negative.append(sum(bool3 & bool4))
false_negative.append(sum(bool3 & bool2))
accuracy.append(metrics.accuracy_score(y_test, y_pred_class))
recall.append(metrics.recall_score(y_test, y_pred_class))
precision.append(metrics.precision_score(y_test, y_pred_class))
f1.append(metrics.f1_score(y_test, y_pred_class))
#%%
# Fam_id
vectorizer = sklearn.feature_extraction.text.CountVectorizer(tokenizer=custom_tokenize) # Tfidf
X  =   vectorizer.fit_transform(df['par_txt'])
y,y_index = pd.factorize(df['fam_id'])

X_train, X_test, y_train, y_test = tts(X, y, random_state=1)

nb = MultinomialNB(alpha=0.95922448979591846, class_prior=[0.1, 0.9],fit_prior=True)

# train the model using X_train_dtm
nb.fit(X_train, y_train)

# make class predictions for X_test_dtm
y_pred_class = nb.predict(X_test)

# calculate predicted probabilities for X_test_dtm (well calibrated)
#y_pred_prob = logreg.predict_proba(X_test_dtm)[:, 1]

print(metrics.confusion_matrix(y_test, y_pred_class))
print('acc: ',metrics.accuracy_score(y_test, y_pred_class))
print('recall: ',metrics.recall_score(y_test, y_pred_class))
print('prec: ',metrics.precision_score(y_test, y_pred_class))
print('f1: ',metrics.f1_score(y_test, y_pred_class))
#%%
bool1 = y_pred_class == 1
bool2 = y_test == 1
bool3 = y_pred_class == 0
bool4 = y_test == 0
true_positive.append(sum(bool3 & bool4))
false_positive.append(sum(bool2 & bool3))
true_negative.append(sum(bool1 & bool2))
false_negative.append(sum(bool4 & bool1))
accuracy.append(metrics.accuracy_score(y_test, y_pred_class))
recall.append(metrics.recall_score(y_test, y_pred_class))
precision.append(metrics.precision_score(y_test, y_pred_class))
f1.append(metrics.f1_score(y_test, y_pred_class))
#%%
# Ignorer
vectorizer = sklearn.feature_extraction.text.CountVectorizer(tokenizer=custom_tokenize) # Tfidf
X  =   vectorizer.fit_transform(df['par_txt'])
y,y_index = pd.factorize(df['igno'])

X_train, X_test, y_train, y_test = tts(X, y, random_state=1)

nb = MultinomialNB(alpha=0.18448979591836737, class_prior=None, fit_prior=True)

# train the model using X_train_dtm
nb.fit(X_train, y_train)

# make class predictions for X_test_dtm
y_pred_class = nb.predict(X_test)

# calculate predicted probabilities for X_test_dtm (well calibrated)
#y_pred_prob = logreg.predict_proba(X_test_dtm)[:, 1]

print(metrics.confusion_matrix(y_test, y_pred_class))
print('acc: ',metrics.accuracy_score(y_test, y_pred_class))
print('recall: ',metrics.recall_score(y_test, y_pred_class))
print('prec: ',metrics.precision_score(y_test, y_pred_class))
print('f1: ',metrics.f1_score(y_test, y_pred_class))
#%%
bool1 = y_pred_class == 1
bool2 = y_test == 1
bool3 = y_pred_class == 0
bool4 = y_test == 0
true_positive.append(sum(bool1 & bool2))
false_positive.append(sum(bool1 & bool4))
true_negative.append(sum(bool3 & bool4))
false_negative.append(sum(bool3 & bool2))
accuracy.append(metrics.accuracy_score(y_test, y_pred_class))
recall.append(metrics.recall_score(y_test, y_pred_class))
precision.append(metrics.precision_score(y_test, y_pred_class))
f1.append(metrics.f1_score(y_test, y_pred_class))
#%%
# kon_kon
vectorizer = sklearn.feature_extraction.text.CountVectorizer(tokenizer=custom_tokenize) # Tfidf
X  =   vectorizer.fit_transform(df['par_txt'])
y,y_index = pd.factorize(df['kon_kon'])

X_train, X_test, y_train, y_test = tts(X, y, random_state=1)

nb = MultinomialNB(alpha=0.10293877551020408, class_prior=None, fit_prior=True)

# train the model using X_train_dtm
nb.fit(X_train, y_train)

# make class predictions for X_test_dtm
y_pred_class = nb.predict(X_test)

# calculate predicted probabilities for X_test_dtm (well calibrated)
#y_pred_prob = logreg.predict_proba(X_test_dtm)[:, 1]

print(metrics.confusion_matrix(y_test, y_pred_class))
print('acc: ',metrics.accuracy_score(y_test, y_pred_class))
print('recall: ',metrics.recall_score(y_test, y_pred_class))
print('prec: ',metrics.precision_score(y_test, y_pred_class))
print('f1: ',metrics.f1_score(y_test, y_pred_class))
#%%
bool1 = y_pred_class == 1
bool2 = y_test == 1
bool3 = y_pred_class == 0
bool4 = y_test == 0
true_positive.append(sum(bool1 & bool2))
false_positive.append(sum(bool1 & bool4))
true_negative.append(sum(bool3 & bool4))
false_negative.append(sum(bool3 & bool2))
accuracy.append(metrics.accuracy_score(y_test, y_pred_class))
recall.append(metrics.recall_score(y_test, y_pred_class))
precision.append(metrics.precision_score(y_test, y_pred_class))
f1.append(metrics.f1_score(y_test, y_pred_class))
#%%
# Kul_rel
vectorizer = sklearn.feature_extraction.text.CountVectorizer(tokenizer=custom_tokenize) # Tfidf
X  =   vectorizer.fit_transform(df['par_txt'])
y,y_index = pd.factorize(df['kul_rel'])

X_train, X_test, y_train, y_test = tts(X, y, random_state=1)

nb = MultinomialNB(alpha=0.12332653061224491, class_prior=None, fit_prior=True)

# train the model using X_train_dtm
nb.fit(X_train, y_train)

# make class predictions for X_test_dtm
y_pred_class = nb.predict(X_test)

# calculate predicted probabilities for X_test_dtm (well calibrated)
#y_pred_prob = logreg.predict_proba(X_test_dtm)[:, 1]

print(metrics.confusion_matrix(y_test, y_pred_class))
print('acc: ',metrics.accuracy_score(y_test, y_pred_class))
print('recall: ',metrics.recall_score(y_test, y_pred_class))
print('prec: ',metrics.precision_score(y_test, y_pred_class))
print('f1: ',metrics.f1_score(y_test, y_pred_class))
#%%
bool1 = y_pred_class == 1
bool2 = y_test == 1
bool3 = y_pred_class == 0
bool4 = y_test == 0
true_positive.append(sum(bool1 & bool2))
false_positive.append(sum(bool1 & bool4))
true_negative.append(sum(bool3 & bool4))
false_negative.append(sum(bool3 & bool2))
accuracy.append(metrics.accuracy_score(y_test, y_pred_class))
recall.append(metrics.recall_score(y_test, y_pred_class))
precision.append(metrics.precision_score(y_test, y_pred_class))
f1.append(metrics.f1_score(y_test, y_pred_class))
#%%
# mil_kli
vectorizer = sklearn.feature_extraction.text.CountVectorizer(tokenizer=custom_tokenize) # Tfidf
X  =   vectorizer.fit_transform(df['par_txt'])
y,y_index = pd.factorize(df['mil_kli'])

X_train, X_test, y_train, y_test = tts(X, y, random_state=1)

nb = MultinomialNB(alpha=0.040912244897959187, class_prior=None, fit_prior=True)

# train the model using X_train_dtm
nb.fit(X_train, y_train)

# make class predictions for X_test_dtm
y_pred_class = nb.predict(X_test)

# calculate predicted probabilities for X_test_dtm (well calibrated)
#y_pred_prob = logreg.predict_proba(X_test_dtm)[:, 1]

print(metrics.confusion_matrix(y_test, y_pred_class))
print('acc: ',metrics.accuracy_score(y_test, y_pred_class))
print('recall: ',metrics.recall_score(y_test, y_pred_class))
print('prec: ',metrics.precision_score(y_test, y_pred_class))
print('f1: ',metrics.f1_score(y_test, y_pred_class))

#%%
bool1 = y_pred_class == 1
bool2 = y_test == 1
bool3 = y_pred_class == 0
bool4 = y_test == 0
true_positive.append(sum(bool1 & bool2))
false_positive.append(sum(bool1 & bool4))
true_negative.append(sum(bool3 & bool4))
false_negative.append(sum(bool3 & bool2))
accuracy.append(metrics.accuracy_score(y_test, y_pred_class))
recall.append(metrics.recall_score(y_test, y_pred_class))
precision.append(metrics.precision_score(y_test, y_pred_class))
f1.append(metrics.f1_score(y_test, y_pred_class))
#%%
# other
vectorizer = sklearn.feature_extraction.text.CountVectorizer(tokenizer=custom_tokenize) # Tfidf
X  =   vectorizer.fit_transform(df['par_txt'])
y,y_index = pd.factorize(df['other'])

X_train, X_test, y_train, y_test = tts(X, y, random_state=1)

nb = MultinomialNB(alpha=0.28642857142857142, class_prior=[0.1, 0.9],fit_prior=True)

# train the model using X_train_dtm
nb.fit(X_train, y_train)

# make class predictions for X_test_dtm
y_pred_class = nb.predict(X_test)

# calculate predicted probabilities for X_test_dtm (well calibrated)
#y_pred_prob = logreg.predict_proba(X_test_dtm)[:, 1]

print(metrics.confusion_matrix(y_test, y_pred_class))
print('acc: ',metrics.accuracy_score(y_test, y_pred_class))
print('recall: ',metrics.recall_score(y_test, y_pred_class))
print('prec: ',metrics.precision_score(y_test, y_pred_class))
print('f1: ',metrics.f1_score(y_test, y_pred_class))
#%%
bool1 = y_pred_class == 1
bool2 = y_test == 1
bool3 = y_pred_class == 0
bool4 = y_test == 0
true_positive.append(sum(bool1 & bool2))
false_positive.append(sum(bool1 & bool4))
true_negative.append(sum(bool3 & bool4))
false_negative.append(sum(bool3 & bool2))
accuracy.append(metrics.accuracy_score(y_test, y_pred_class))
recall.append(metrics.recall_score(y_test, y_pred_class))
precision.append(metrics.precision_score(y_test, y_pred_class))
f1.append(metrics.f1_score(y_test, y_pred_class))
#%%
# Sta_tek
vectorizer = sklearn.feature_extraction.text.TfidfVectorizer(tokenizer=custom_tokenize) # Tfidf
X  =   vectorizer.fit_transform(df['par_txt'])
y,y_index = pd.factorize(df['sta_tek'])

X_train, X_test, y_train, y_test = tts(X, y, random_state=1)

nb = MultinomialNB(alpha=0.24565306122448982, class_prior=None, fit_prior=True)

# train the model using X_train_dtm
nb.fit(X_train, y_train)

# make class predictions for X_test_dtm
y_pred_class = nb.predict(X_test)

# calculate predicted probabilities for X_test_dtm (well calibrated)
#y_pred_prob = logreg.predict_proba(X_test_dtm)[:, 1]

print(metrics.confusion_matrix(y_test, y_pred_class))
print('acc: ',metrics.accuracy_score(y_test, y_pred_class))
print('recall: ',metrics.recall_score(y_test, y_pred_class))
print('prec: ',metrics.precision_score(y_test, y_pred_class))
print('f1: ',metrics.f1_score(y_test, y_pred_class))

#%%
bool1 = y_pred_class == 1
bool2 = y_test == 1
bool3 = y_pred_class == 0
bool4 = y_test == 0
true_positive.append(sum(bool3 & bool4))
false_positive.append(sum(bool2 & bool3))
true_negative.append(sum(bool1 & bool2))
false_negative.append(sum(bool4 & bool1))
accuracy.append(metrics.accuracy_score(y_test, y_pred_class))
recall.append(metrics.recall_score(y_test, y_pred_class))
precision.append(metrics.precision_score(y_test, y_pred_class))
f1.append(metrics.f1_score(y_test, y_pred_class))
#%%

df_matrix['emne'] = Emne
df_matrix['true_positive'] = true_positive
df_matrix['false_positive'] = false_positive
df_matrix['true_negative'] = true_negative
df_matrix['false_negative'] = false_negative
df_matrix['accuracy'] = accuracy
df_matrix['recall'] = recall
df_matrix['precision'] = precision
df_matrix ['f1'] = f1
#%%
df_matrix.set_index('emne', inplace=True)

#%%
writer = pd.ExcelWriter('ConfusionMatrixTable1.xlsx')
df_matrix.to_excel(writer,'Sheet1')
writer.save()